<!DOCTYPE html>
<html>
<head>
    <title>Öğrenci Bilgi Sistemi</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .logo {
            width: 100%;
            height: auto;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .family-logo {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 250px;
            height: auto;
            padding: 10px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            background-color: #343a40;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .sidebar a {
            padding: 15px;
            text-align: center;
            width: 90%;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s;
            margin-bottom: 10px;
            border-radius: 5px;
            font-size: 1.1em;
        }
        .sidebar a:hover {
            background-color: #007bff;
            color: white;
        }
        .content {
            margin-left: 290px;
            padding: 20px;
            position: relative;
            min-height: 100vh;
        }
        .background-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('üniversite.jpg') no-repeat center center;
            background-size: cover;
            z-index: -1;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .content h1, .content h2 {
            color: #ffffff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <img src="duyuru.jpg" alt="logo" class="logo">
        <a href="student_register.php" class="btn btn-primary">Öğrenci Olarak Kayıt Ol</a>
        <a href="student_login.php" class="btn btn-secondary">Öğrenci Olarak Giriş Yap</a>
        <a href="faculty_register.php" class="btn btn-primary">Akademik Personel Olarak Kayıt Ol</a>
        <a href="faculty_login.php" class="btn btn-secondary">Akademik Personel Olarak Giriş Yap</a>
    </div>
    <div class="content">
        <div class="background-image"></div>
        <div class="overlay"></div>
        <img src="aile.png" alt="family logo" class="family-logo">
        <h1 class="text-center mt-5">Başkent Üniversitesi</h1>
        <h2 class="text-center mt-3">Öğrenci Bilgi Sistemi</h2>
    </div>
</body>
</html>
