<?php
include('db.php'); 

session_start();

if(!isset($_SESSION['login_user'])){
    header("location: faculty_login.php");
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Akademik Personel Paneli</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5">Akademik Personel Paneli</h1>
        <div class="d-flex justify-content-center mt-4">
            <a href="add_student_grade.php" class="btn btn-primary m-2">Öğrenci Not Ekle</a>
            <a href="delete_student.php" class="btn btn-secondary m-2">Öğrenci Sil</a>
            <a href="view_students.php" class="btn btn-primary m-2">Öğrencileri Görüntüle</a>
            <a href="logout.php" class="btn btn-danger m-2">Çıkış Yap</a>
        </div>
    </div>
</body>
<style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .overlay img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: auto;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
    </style>
</html>
