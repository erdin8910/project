<?php
include('db.php'); 

session_start();

if(!isset($_SESSION['login_user'])){
    header("location: faculty_login.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_no = $_POST['student_no'];
    $midterm = $_POST['midterm'];
    $final = $_POST['final'];
    $project = $_POST['project'];
    $ders_kodu = $_POST['ders_kodu'];

    
    if (!empty($student_no) && !empty($midterm) && !empty($final) && !empty($project) && !empty($ders_kodu)) {
        $average = ($midterm * 0.3) + ($final * 0.6) + ($project * 0.1);

        
        $student_name = isset($_POST['name']) ? $_POST['name'] : '';
        $student_surname = isset($_POST['surname']) ? $_POST['surname'] : '';

        $sql = "INSERT INTO students (id, name, surname, student_no, midterm, final, project, average, ders_kodu)
                VALUES ('', '$student_name', '$student_surname', '$student_no', '$midterm', '$final', '$project', '$average', '$ders_kodu')";
        if (mysqli_query($conn, $sql)) {
            echo "<div class='alert alert-success mt-3'>Notlar başarıyla eklendi.</div>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Hata: " . $sql . "<br>" . mysqli_error($conn) . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger mt-3'>Lütfen tüm alanları doldurun.</div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Öğrenci Not Ekle</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5">Öğrenci Not Ekle</h1>
        <form method="post" action="" class="mt-4">
            <div class="form-group">
                <label for="student_no">Öğrenci No</label>
                <input type="text" name="student_no" class="form-control" id="student_no" required>
            </div>
            <div class="form-group">
                <label for="name">Ad</label>
                <input type="text" name="name" class="form-control" id="name" required>
            </div>
            <div class="form-group">
                <label for="surname">Soyad</label>
                <input type="text" name="surname" class="form-control" id="surname" required>
            </div>
            <div class="form-group">
                <label for="midterm">Vize Notu</label>
                <input type="text" name="midterm" class="form-control" id="midterm" required>
            </div>
            <div class="form-group">
                <label for="final">Final Notu</label>
                <input type="text" name="final" class="form-control" id="final" required>
            </div>
            <div class="form-group">
                <label for="project">Proje Notu</label>
                <input type="text" name="project" class="form-control" id="project" required>
            </div>
            <div class="form-group">
                <label for="ders_kodu">Ders Kodu</label>
                <input type="text" name="ders_kodu" class="form-control" id="ders_kodu" required>
            </div>
            <button type="submit" class="btn btn-primary">Not Ekle</button>
        </form>
    </div>
</body>
<style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .overlay img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: auto;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
    </style>
</html>
