<?php
$servername = "localhost";
$username = "root";
$password = "web364web"; 
$dbname = "student_management"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}


$students_table = "CREATE TABLE IF NOT EXISTS students (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    id VARCHAR(50),
    password VARCHAR(255),
    name VARCHAR(50),
    surname VARCHAR(50),
    student_no VARCHAR(50),
    midterm FLOAT DEFAULT 0,
    final FLOAT DEFAULT 0,
    project FLOAT DEFAULT 0,
    average FLOAT DEFAULT 0,
    ders_kodu VARCHAR(50)
)";

$faculty_table = "CREATE TABLE IF NOT EXISTS faculty (
    id VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(50) NOT NULL,
    surname VARCHAR(50) NOT NULL
)";

if ($conn->query($students_table) === TRUE) {
    echo "Students tablosu başarıyla oluşturuldu.";
} else {
    echo "Hata: " . $conn->error;
}

if ($conn->query($faculty_table) === TRUE) {
    echo "Faculty tablosu başarıyla oluşturuldu.";
} else {
    echo "Hata: " . $conn->error;
}
?>
