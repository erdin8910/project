<?php
include('db.php'); 
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $student_no = $_POST['student_no'];

    
    $sql = "INSERT INTO students (id, password, name, surname, student_no) VALUES ('$id', '$password', '$name', '$surname', '$student_no')";
    if (mysqli_query($conn, $sql)) {
        $message = "Kayıt başarılı! Giriş yapmak için <a href='student_login.php'>tıklayınız</a>.";
    } else {
        $message = "Hata: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Öğrenci Kayıt</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
        .message {
            margin-top: 20px;
            font-size: 1.1em;
            color: #28a745;
        }
    </style>
</head>
<body>
    <div class="overlay"></div>
    <div class="container">
        <h1 class="text-center mt-5">Öğrenci Kayıt</h1>
        <?php if ($message != ""): ?>
            <div class="message text-center">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form method="post" action="" class="mt-4">
            <div class="form-group">
                <label for="id">ID</label>
                <input type="text" name="id" class="form-control" id="id" required>
            </div>
            <div class="form-group">
                <label for="password">Şifre</label>
                <input type="password" name="password" class="form-control" id="password" required>
            </div>
            <div class="form-group">
                <label for="name">Ad</label>
                <input type="text" name="name" class="form-control" id="name" required>
            </div>
            <div class="form-group">
                <label for="surname">Soyad</label>
                <input type="text" name="surname" class="form-control" id="surname" required>
            </div>
            <div class="form-group">
                <label for="student_no">Öğrenci No</label>
                <input type="text" name="student_no" class="form-control" id="student_no" required>
            </div>
            <button type="submit" class="btn btn-primary">Kayıt Ol</button>
        </form>
    </div>
</body>
</html>
