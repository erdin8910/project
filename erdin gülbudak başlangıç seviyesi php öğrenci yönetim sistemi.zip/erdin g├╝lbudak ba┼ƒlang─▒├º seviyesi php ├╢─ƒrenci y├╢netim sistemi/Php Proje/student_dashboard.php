<?php
include('db.php'); 

session_start();

if(!isset($_SESSION['login_user'])){
    header("location: student_login.php");
}

$user_id = $_SESSION['login_user'];
$sql = "SELECT * FROM students WHERE id='$user_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Öğrenci Paneli</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5">Öğrenci Paneli</h1>
        <div class="card mt-4">
            <div class="card-body">
                <h5 class="card-title">ID: <?php echo $row['id']; ?></h5>
                <p class="card-text">Ad: <?php echo $row['name']; ?></p>
                <p class="card-text">Soyad: <?php echo $row['surname']; ?></p>
                <p class="card-text">Öğrenci No: <?php echo $row['student_no']; ?></p>
                <p class="card-text">Vize Notu: <?php echo $row['midterm']; ?></p>
                <p class="card-text">Final Notu: <?php echo $row['final']; ?></p>
                <p class="card-text">Proje Notu: <?php echo $row['project']; ?></p>
                <p class="card-text">Ortalama: <?php echo $row['average']; ?></p>
                <p class="card-text">Ders Kodu: <?php echo $row['ders_kodu']; ?></p>

                <a href="logout.php" class="btn btn-danger mt-3">Çıkış Yap</a>
            </div>
        </div>
    </div>
</body>
<style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .overlay img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: auto;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
    </style>
</html>
