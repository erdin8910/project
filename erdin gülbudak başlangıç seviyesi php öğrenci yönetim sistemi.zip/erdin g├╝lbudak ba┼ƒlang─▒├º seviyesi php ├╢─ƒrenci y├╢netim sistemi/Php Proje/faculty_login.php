<?php
include('db.php'); 

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM faculty WHERE id='$id' and password='$password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['login_user'] = $id;
        header("location: faculty_dashboard.php");
    } else {
        $error = "ID veya Şifre hatalı.";
    }
}
?>

<!DOCTYPE html>
<html>
head>
    <title>Akademik Personel Giriş</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5">Akademik Personel Giriş</h1>
        <form method="post" action="" class="mt-4">
            <div class="form-group">
                <label for="id">ID</label>
                <input type="text" name="id" class="form-control" id="id" required>
            </div>
            <div class="form-group">
                <label for="password">Şifre</label>
                <input type="password" name="password" class="form-control" id="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Giriş Yap</button>
        </form>
        <?php if(isset($error)) { echo '<div class="alert alert-danger mt-3">' . $error . '</div>'; } ?>
    </div>
</body>
<style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .overlay img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: auto;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
    </style>
</html>
