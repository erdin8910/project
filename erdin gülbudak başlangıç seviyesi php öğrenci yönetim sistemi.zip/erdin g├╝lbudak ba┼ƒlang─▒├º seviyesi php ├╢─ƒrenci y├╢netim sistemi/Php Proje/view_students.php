<?php
include('db.php'); 

session_start();

if(!isset($_SESSION['login_user'])){
    header("location: faculty_login.php");
}


$sql = "SELECT * FROM students WHERE student_no IS NOT NULL AND student_no != '' AND ders_kodu IS NOT NULL AND ders_kodu != '' AND name IS NOT NULL AND name != '' AND surname IS NOT NULL AND surname != ''";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Öğrencileri Görüntüle</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5">Öğrencileri Görüntüle</h1>
        <table class="table table-striped mt-4">
            <thead>
                <tr>
                    <th>Record ID</th>
                    <th>ID</th>
                    <th>Ad</th>
                    <th>Soyad</th>
                    <th>Öğrenci No</th>
                    <th>Vize</th>
                    <th>Final</th>
                    <th>Proje</th>
                    <th>Ortalama</th>
                    <th>Ders Kodu</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['record_id']; ?></td>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['surname']; ?></td>
                    <td><?php echo $row['student_no']; ?></td>
                    <td><?php echo $row['midterm']; ?></td>
                    <td><?php echo $row['final']; ?></td>
                    <td><?php echo $row['project']; ?></td>
                    <td><?php echo $row['average']; ?></td>
                    <td><?php echo $row['ders_kodu']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="faculty_dashboard.php" class="btn btn-secondary mt-3">Geri Dön</a>
    </div>
</body>
<style>
        body {
            background: url('üniversite.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            min-height: 100vh;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .overlay img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: auto;
            z-index: -1;
        }
        .container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h1, label {
            color: #343a40;
        }
    </style>
</html>
